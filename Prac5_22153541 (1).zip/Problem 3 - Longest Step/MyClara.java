/* PERMITTED COMMANDS
   move(); turnLeft(); turnRight(); treeLeft(); treeRight(); treeFront(); onLeaf(); putLeaf(); removeLeaf();
   JAVA
   if, else, for, while, do, !, ||, && 
   variables
*/
   
class MyClara extends Clara { 
    /**
     * In the 'run()' method you can write your program for Clara 
     */
    void run() {
        int a = 0;
        int longestStep = 0;
        // TODO: Write your code below
        // reset counter
        if (treeFront() && treeRight() && !treeLeft()){
            moveAround();
            a = 0;
        }
        // movement foundation
        while (!treeFront()){
            move();
        if (treeFront() && treeLeft() && treeRight()){
            removeLeaf();
        }
        // incremente counter
        if (treeRight()){
            a++;
        }
        // finds longest step
        if (a > longestStep){
            longestStep = a;
        }
         if (treeFront() && treeRight() && !treeLeft()){
            moveAround();
            a = 0;
        }
    }
    System.out.println("longest step = " + longestStep);
    }
    void moveAround(){
        turnLeft();
        move();
        turnRight();
    } 
}