/* PERMITTED COMMANDS
   move(); turnLeft(); turnRight(); treeLeft(); treeRight(); treeFront(); onLeaf(); putLeaf(); removeLeaf();
   JAVA
   if, else, for, while, do, !, ||, && 
   variables
*/
   
class MyClara extends Clara { 
    /**
     * In the 'run()' method you can write your program for Clara 
     */
     boolean isComplete = true;
    void run() {
        // TODO: Write your code below
        // remove leaves
        if (onLeaf()){
            removeLeaf();
        }
        // removes leaves from different situations
        while (!mushroomFront()){
            move();
            if (onLeaf()){
                removeLeaf();
            }
            // foundation of turns
            if (treeFront() && treeRight()){
                turnLeft();
            }
            if (treeFront() && treeLeft()){
                turnRight();
            }
            if (treeFront()){
                turnLeft();
            }
            if (mushroomFront()){
                System.out.println(isComplete);
            }
        }
    }
}