/* PERMITTED COMMANDS
   move(); turnLeft(); turnRight(); treeLeft(); treeRight(); treeFront(); onLeaf(); putLeaf(); removeLeaf();
   JAVA
   if, else, for, while, do, !, ||, && 
   variables
*/
   
class MyClara extends Clara { 
    /**
     * In the 'run()' method you can write your program for Clara 
     */
    void run() {
        int a = 0;
        int b = 0;
        // TODO: Write your code below
        // leave counter and step counter 
        while (!treeFront()){
            if (onLeaf()){
                removeLeaf();
                b = b + 1;
            }
            move();
            a = a + 1;
        // leave counter again to get the count correct
        if (treeFront()){
            turnRight();
            if (treeFront() && treeLeft()){
                turnGrabLeaf();
                b = b + 1;
            }
        }
        }
        System.out.println(b + " leaves, " + a + " steps");
    }
    void turnGrabLeaf(){
        turnLeft();
        removeLeaf();
    }
}