/* PERMITTED COMMANDS
   move(); turnLeft(); turnRight(); treeLeft(); treeRight(); treeFront(); onLeaf(); putLeaf(); removeLeaf();
   JAVA
   if, else, for, while, do, !, ||, && 
   variables
*/
   
class MyClara extends Clara { 
    int counter = 0;
    int leaveCounter = 0;
    boolean onCheck = true;
    /**
     * In the 'run()' method you can write your program for Clara 
     */
     
    void run() {
        // TODO: Write your code below
        // counts where the leaves are placed
        while (!treeFront()){
            move();
             if (!onLeaf()){
            if (leaveCounter % 2 == 1){
                putLeaf();
            }
        }
            leaveCounter++;
            // movement foundation
        if (treeFront()){
           counter++;
           if (counter % 2 == 0){
               turnRight();
               move();
               turnRight();
           }
           else{
               turnLeft();
               move();
               if (treeRight()){
                   turnLeft();
               } else{
                   turnLeft();
               }    
           }
           }

        }  
        }
}